class Constant(object):
    def __init__(self):
        self.OK = 200
        self.NOT_FOUND = 404